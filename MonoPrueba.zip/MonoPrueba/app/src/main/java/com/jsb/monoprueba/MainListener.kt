package com.jsb.monoprueba

interface MainListener {
    fun onStarted()
    fun onSuccess()
    fun onFailure(message:String)
}