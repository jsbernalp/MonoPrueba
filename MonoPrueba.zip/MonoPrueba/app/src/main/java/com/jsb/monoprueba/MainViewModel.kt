package com.jsb.monoprueba

import android.view.View
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel(){

    var Nombres:String? = null
    var Email:String? = null
    var Password:String? = null

    var mainListener:MainListener? = null

    fun onRegisterButtonClick(view: View){

        mainListener?.onStarted()

        if (Nombres.isNullOrEmpty() || Email.isNullOrEmpty() || Password.isNullOrEmpty()){
            mainListener?.onFailure("invalid email or name or password")
            return
        }

        mainListener?.onSuccess()

    }
}